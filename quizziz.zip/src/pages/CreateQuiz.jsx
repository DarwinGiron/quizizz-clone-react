
import React from 'react';
import QuizForm from '../components/QuizForm';

const CreateQuiz = () => {
  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold mb-4">Crear Nuevo Quiz</h2>
      <QuizForm />
    </div>
  );
};

export default CreateQuiz;
