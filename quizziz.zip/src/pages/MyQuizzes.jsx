import React, { useEffect, useRef, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Link, useNavigate } from 'react-router-dom';
import { FiMoreVertical, FiEye } from 'react-icons/fi';

const MyQuizzes = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(null);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'quizzes'));
        const fetched = [];
        querySnapshot.forEach((doc) => {
          fetched.push({ id: doc.id, ...doc.data() });
        });
        setQuizzes(fetched);
      } catch (err) {
        console.error('Error al obtener quizzes', err);
      }
    };

    fetchQuizzes();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDelete = (id) => {
    alert(`Eliminar quiz con ID: ${id}`);
  };

  const handleDuplicate = (quiz) => {
    alert(`Duplicar quiz con ID: ${quiz.id}`);
  };

  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };

  const toggleDropdown = (index) => {
    setDropdownOpen(dropdownOpen === index ? null : index);
  };

  return (
    <div className="flex justify-center pt-8 min-h-[60vh] p-8">
      <div className="w-full max-w-6xl">
        <h1 className="text-2xl font-bold mb-6 text-center">Mis Quizzes</h1>

        {quizzes.length === 0 ? (
          <p className="text-center">No tienes quizzes aún.</p>
        ) : (
          <div className="flex justify-center">
            <div className="grid grid-cols-1 gap-6 w-full max-w-5xl">
              {quizzes
                .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
                .map((quiz, index) => {
                  const partidasJugadas = Math.floor(Math.random() * 40) + 1;
                  const personalAsistio = partidasJugadas * (Math.floor(Math.random() * 5) + 1);

                  return (
                    <div
                      key={quiz.id}
                      className="bg-white rounded-lg shadow-md px-6 py-4 transition-transform transform hover:-translate-y-1 hover:shadow-xl w-full"
                    >
                      <div className="flex justify-between items-center">
                        <h2 className="text-lg font-bold text-black">{quiz.title}</h2>
                        <div className="flex items-center gap-4">
                          <Link
                            to={`/preview/${quiz.id}`}
                            title="Vista previa"
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <FiEye size={20} />
                          </Link>
                          <div className="relative" ref={dropdownRef}>
                            <button
                              onClick={() => toggleDropdown(index)}
                              className="text-gray-700 hover:text-black"
                            >
                              <FiMoreVertical size={24} />
                            </button>
                            {dropdownOpen === index && (
                              <div className="absolute right-0 mt-2 w-40 bg-white border rounded shadow z-10">
                                <button
                                  onClick={() => window.location.href = `/live/${quiz.id}`}
                                  className="w-full text-left px-3 py-2 hover:bg-gray-100"
                                  title="Crear sesión en vivo"
                                >
                                  Sesión en vivo
                                </button>

                                <button
                                  onClick={() => handleEdit(quiz.id)}
                                  className="w-full text-left px-3 py-2 hover:bg-gray-100"
                                >
                                  Editar
                                </button>
                                <button
                                  onClick={() => handleDuplicate(quiz)}
                                  className="w-full text-left px-3 py-2 hover:bg-gray-100"
                                >
                                  Duplicar
                                </button>
                                <button
                                  onClick={() => handleDelete(quiz.id)}
                                  className="w-full text-left px-3 py-2 hover:bg-gray-100 text-red-500"
                                >
                                  Eliminar
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mt-2 flex flex-wrap items-center gap-x-4">
                        📋 {quiz.questions?.length || 0} preguntas
                        🎮 {partidasJugadas} partidas jugadas
                        👥 {personalAsistio} personas capacitadas
                      </p>
                    </div>
                  );
                })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyQuizzes;
