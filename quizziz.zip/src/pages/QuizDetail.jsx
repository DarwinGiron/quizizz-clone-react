
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

const QuizDetail = () => {
  const { id } = useParams();
  const [quiz, setQuiz] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        const docRef = doc(db, 'quizzes', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setQuiz(docSnap.data());
        } else {
          setQuiz(null);
        }
      } catch (error) {
        console.error('Error al cargar el quiz:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchQuiz();
  }, [id]);

  if (loading) return <p className="p-4">Cargando...</p>;
  if (!quiz) return <p className="p-4 text-red-500">Quiz no encontrado</p>;

  return (
    <div className="p-6 space-y-4">
      <h2 className="text-3xl font-bold">{quiz.title}</h2>
      <p className="text-gray-500">Categoría: {quiz.category} | Dificultad: {quiz.difficulty}</p>

      {quiz.questions && quiz.questions.map((q, i) => (
        <div key={i} className="border p-4 rounded shadow bg-white">
          <h3 className="font-semibold">Pregunta {i + 1}: {q.text}</h3>
          <ul className="list-disc ml-6 mt-2">
            {q.options.map((opt, j) => (
              <li key={j} className={q.answer === j ? 'text-green-600 font-bold' : ''}>
                {opt}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default QuizDetail;
