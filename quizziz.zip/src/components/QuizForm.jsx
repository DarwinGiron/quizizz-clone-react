import React, { useState } from 'react';
import { db } from "../firebase/config";
import { collection, addDoc } from "firebase/firestore";

import QuestionCard from './QuestionCard';

const CreateQuiz = () => {
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState([
    { text: '', options: ['', '', '', ''], answer: null },
  ]);

  const handleUpdate = (index, updatedQuestion) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index] = updatedQuestion;
    setQuestions(updatedQuestions);
  };

  const handleDelete = (index) => {
    const updated = questions.filter((_, i) => i !== index);
    setQuestions(updated);
  };

  const addQuestion = () => {
    setQuestions([...questions, { text: '', options: ['', '', '', ''], answer: null }]);
  };

const handleSave = async () => {
  try {
    await addDoc(collection(db, "quizzes"), {
      title,
      questions,
      createdAt: new Date()
    });
    alert("Quiz guardado con éxito");
  } catch (error) {
    console.error("Error al guardar el quiz:", error);
    alert("Ocurrió un error al guardar el quiz.");
  }
};



  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Crear Nuevo Quiz</h1>

      <input
        type="text"
        placeholder="Título del Quiz"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full p-2 border border-gray-300 rounded mb-4"
      />

      {questions.map((q, index) => (
        <div key={index} className="mb-6">
          <QuestionCard
            q={q}
            index={index}
            onUpdate={handleUpdate}
            onDelete={handleDelete}
            editable={true}
          />
        </div>
      ))}

      <div className="flex gap-4 mt-6">
        <button
          onClick={addQuestion}
          className="bg-purple-600 text-white px-4 py-2 rounded"
        >
          + Añadir Pregunta
        </button>
        <button
          onClick={handleSave}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          Guardar Quiz
        </button>
      </div>
    </div>
  );
};

export default CreateQuiz;
