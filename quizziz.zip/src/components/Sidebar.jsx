
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FiBookOpen, FiHome, FiPlusCircle, FiLogOut } from 'react-icons/fi';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase/config';

const Sidebar = () => {
  const location = useLocation();
  const active = (path) => location.pathname === path ? 'bg-purple-100 text-purple-700' : 'text-gray-700';

  return (
    <div className="h-screen w-60 bg-white border-r shadow-sm fixed left-0 top-0 flex flex-col justify-between">
      <div className="p-6">
        <h1 className="text-xl font-bold text-purple-700 mb-8">QUIZZIZ CLONE</h1>
        <nav className="flex flex-col space-y-4">
          <Link to="/dashboard" className={`flex items-center gap-2 px-3 py-2 rounded hover:bg-purple-50 ${active('/dashboard')}`}>
            <FiHome /> Principal
          </Link>
          <Link to="/myquizzes" className={`flex items-center gap-2 px-3 py-2 rounded hover:bg-purple-50 ${active('/myquizzes')}`}>
            <FiBookOpen /> Biblioteca
          </Link>
          <Link to="/create" className={`flex items-center gap-2 px-3 py-2 rounded hover:bg-purple-50 ${active('/create')}`}>
            <FiPlusCircle /> Crear Quiz
          </Link>
        </nav>
      </div>
      <div className="p-6 border-t">
        <button onClick={() => signOut(auth)} className="flex items-center gap-2 text-sm text-gray-600 hover:text-red-500">
          <FiLogOut /> Cerrar sesión
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
